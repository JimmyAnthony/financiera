﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
	
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Demo: Many languages | Quizzpot</title>

<link rel="stylesheet" type="text/css" href="../ext-2.2/resources/css/ext-all.css" />

<script type="text/javascript" src="../ext-2.2/adapter/ext/ext-base.js"></script>
<script type="text/javascript" src="../ext-2.2/ext-all.js"></script>
<script type="text/javascript" src="../ext-2.2/locale/ext-lang-es-min.js"></script>

<script type="text/javascript" src="yourlanguage.js"></script>
<script type="text/javascript" src="manylanguages.js"></script>
<style type="text/css">
	.cmb{
		float:right;
		margin:5px;
	}
</style>
</head>
<body>
<div class="cmb">
	<select id="language">
		<option value="en">English</option>
		<option value="es">Español</option>
		<option value="it">Italiano</option>
		<option value="pt">Português</option>
		<option value="ro">Română (Romanian)</option>
	</select>
</div>
</body>
</html>